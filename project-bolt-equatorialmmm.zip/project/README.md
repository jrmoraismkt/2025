memoria
